import React from 'react'
import { FaTimes } from 'react-icons/fa'
const Modal = () => {
  return <h2>Modal</h2>
}

export default Modal
